    
from selenium import webdriver
from selenium.webdriver.common.by import By




class Home:
    
    
    
    sign_in_button    = (By.CSS_SELECTOR, "div.header_user_info > a")
    contact_us_button = (By.ID, 'contact-link')
    your_logo         = (By.XPATH, '//*[@id="header_logo"]/a/img')
    
    
    
    def __init__(self, driver):
        self.driver = driver