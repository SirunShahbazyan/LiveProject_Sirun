from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from Lib import LIB
import json
import sys
import os
import pytest




class Contact_Us:
    
    subject_heading = (By.ID, "id_contact")
    email_address   = (By.XPATH, '//*[@id="email"]')
    order_reference = (By.ID, 'id_order')
    message_text    = (By.ID, 'message')
    send_button     = (By.ID, 'submitMessage')
    success_message = (By.XPATH, '//*[@id="center_column"]/p')
    error_message   = (By.XPATH, '//*[@id="center_column"]/div/ol/li')
    
    
    
    def __init__(self,driver):
        self.driver = driver
        
        
        
        
    def choose_subject_heading(self,driver):
        LIB.wait_for_element(self, driver, self.subject_heading)
        select_text = LIB.get_data(self, key = 'subject_heading')
        element = self.driver.find_element(*self.subject_heading)
        element.click()
        select = Select(element)
        select.select_by_visible_text(select_text)
        
        
    
    def input_email_address(self):
        email_value = LIB.get_data(self, key = 'valid_mail')
        self.driver.find_element(*self.email_address).send_keys(email_value)
        
    
    
    def input_message(self):
        message = LIB.get_data(self, "contact_us_input_message")
        self.driver.find_element(*self.message_text).send_keys(message)
    
    
    def click_send_button(self):
        self.driver.find_element(*self.send_button).click()