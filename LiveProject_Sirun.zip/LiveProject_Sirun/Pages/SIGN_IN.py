from selenium import webdriver
from selenium.webdriver.common.by import By
from Lib import LIB
import pytest




    
    
class Sign_In:
    


    
    email_address  = (By.ID, "email")
    password       = (By.ID, "passwd")
    sign_in        = (By.ID, "SubmitLogin")
    my_account     = (By.XPATH, '//*[@id="center_column"]/h1')

       

    def __init__(self,driver):
        self.driver = driver
        
    
        
    
    
    
    
               

