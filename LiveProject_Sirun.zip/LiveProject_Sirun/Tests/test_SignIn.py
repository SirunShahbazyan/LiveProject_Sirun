from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from Pages.SIGN_IN import Sign_In
from Pages.HOME import Home
from Lib import LIB
import json
import pytest
import os



def test_1():
    try:
    
    
        obj_lib = LIB()
        driver = obj_lib.open_driver()
        email_address = obj_lib.config_data["EMAIL"]
        password = obj_lib.config_data["PASSWORD"]
            
        obj_lib.page_load(driver)
            
        obj_home = Home(driver)
        driver.find_element(*obj_home.sign_in_button).click()
            
        obj_sign_in = Sign_In(driver)
            
            
        obj_lib.wait_for_element(driver, obj_sign_in.email_address)
        driver.find_element(*obj_sign_in.email_address).send_keys(email_address)
        driver.find_element(*obj_sign_in.password).send_keys(password)
               
        driver.find_element(*obj_sign_in.sign_in).click()
        
        assert driver.find_element(*obj_sign_in.my_account), obj_lib.save_screenshot(driver)
        print("Test pass")
            
  
    finally:
        obj_lib.close_driver(driver)
  

test_1()     

    
    
    
    
