from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains 
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from Pages.SIGN_IN import Sign_In
from Pages.HOME import Home
from Lib import LIB
from Pages.CONTACT_US import Contact_Us
from selenium.webdriver.support.select import Select
import json
import pytest
import os
import time





def test_2():
    try:
    
        #Creat Lib object, open driver and load page
        obj_lib = LIB()
        driver = obj_lib.open_driver()
        obj_lib.page_load(driver)
        
        
        #Create HOME page object
        obj_home = Home(driver)
        
        
        #Click "contact us" button
        el = driver.find_element(*obj_home.contact_us_button)
        el.click()    
        
       
        #Create CONTACT_US page object  
        obj_contact_us = Contact_Us(driver)
        
        
        #Call functions from CONTACT_US
        obj_contact_us.choose_subject_heading(driver)
        obj_contact_us.input_email_address()
        obj_contact_us.input_message()
        obj_contact_us.click_send_button()
        
        
        #Verify if message is sent successfully
        success_message = obj_lib.get_data("contact_us_success_message")
        
        message_text = driver.find_element(*obj_contact_us.success_message).text
        assert success_message in message_text, obj_lib.save_screenshot(driver)
        print("Test pass")
    
   
    finally:
        #Close driver
        obj_lib.close_driver(driver)
    
    
    
test_2()
    