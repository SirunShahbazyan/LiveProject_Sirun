
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import NoSuchElementException
from selenium import webdriver
import os
import sys
import json



class LIB:
    
    def __init__(self):
        self.config_data = self.load_config()
        
        
    def load_config(self):
        with open("config.json") as f:
            data = json.load(f)
            return data
             

    def open_driver(self):
        try:
            driver = webdriver.Chrome(self.config_data['driver_path'])
            driver.maximize_window()
            return driver
        except:
            print("Smth went wrong while opening driver")
            
    
    
    def page_load(self, driver):
        try:
             driver.get(self.config_data['URL'])
           
        except:
            print("Smth wrong while loading page")
    
    
    
    def move_to_element(self, driver, element):
        try:
            action=ActionChains(driver)
            action.move_to_element(element).perform()
        except:
            print("Can't move to the element")
     
     
     
    def wait_for_elements(self, driver, elements):
        try:
            WebDriverWait(driver,10).until(EC.visibility_of_any_elements_located(elements))
        except:
            print("Elements are not visible")
        
        
            
    def wait_for_element(self, driver, element):
        try:
            WebDriverWait(driver,10).until(EC.visibility_of_any_element_located(element))
        except:
            print("Element are not visible")
         
         
         
            
    def get_data(self, key):
        try:
            with open ("data.json") as f:
                data=json.load(f)
                return data[key]
        except:
            print("Error while getting data")
    
    
    
    
    def save_screenshot(self, driver):
        current_filename = os.path.basename(sys.argv[0][:-3])
        try:
            driver.save_screenshot(f"Test\\{current_filename}_screenshot.png")
        except:
            print("Screenshot is not saved")
    
     
        
    def close_driver(self, driver):
        try:
            driver.quit()
        except:
            print("Driver is not closed")